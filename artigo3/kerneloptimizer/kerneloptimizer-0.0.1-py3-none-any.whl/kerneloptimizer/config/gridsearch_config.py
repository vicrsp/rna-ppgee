import numpy as np


grid_params = {
    'rbf_svm': {
        'C': 2. ** np.arange(-5,16),
        'gamma': 1. / (2. * ((2. ** np.arange(-15, 4)) ** 2.))
       #'gamma': 2. ** np.arange(-15, 4)
    },
    'sigmoid_svm': {
        'C': 2. ** np.arange(-5,16),
        'gamma': 2. ** np.arange(-15, 4),
        'coef0': 2. ** np.arange(-15, 4)
    },
    'laplacian_svm': {
        'C': 2. ** np.arange(-5,16),
        'sigma': 2. ** np.arange(-15, 4)
    }
}

