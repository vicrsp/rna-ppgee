import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd as autograd
import torch.optim as optim

from kerneloptimizer.functions import loss_functions
from kerneloptimizer.neural_nets.mlp.early_stopping import EarlyStopping
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC


class MLP_with_classification(torch.nn.Module):

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MLP_with_classification, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.layer1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
        self.layer1.weight.data.uniform_(-1.0, 1.0)
        self.tanh = torch.nn.Tanh()
        self.layer2 = torch.nn.Linear(self.hidden_dim, self.output_dim)
        self.layer2.weight.data.uniform_(-1.0, 1.0)
        self.sigmoid = torch.nn.Sigmoid()
        self.relu = torch.nn.ReLU()
        self.tanh = torch.nn.Tanh()
        self.layer3 = torch.nn.Linear(self.output_dim, 1)
        self.out_sigmoid = torch.nn.Sigmoid()

    def forward(self, x):
        x = self.layer1(x)
        x = self.tanh(x)
        x = self.layer2(x)
        output = self.sigmoid(x) / np.sqrt(self.output_dim)
        output = F.normalize(output, dim=1)

        output = self.layer3(output)
        output = self.out_sigmoid(output)

        return output

class MLP_pretrain(torch.nn.Module):

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MLP_pretrain, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim

        self.layer1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
        self.layer1.weight.data.uniform_(-1.0, 1.0)
        self.tanh = torch.nn.Tanh()
        self.layer2 = torch.nn.Linear(self.hidden_dim, self.output_dim)
        self.layer2.weight.data.uniform_(-1.0, 1.0)
        self.sigmoid = torch.nn.Sigmoid()
        self.relu = torch.nn.ReLU()
        self.tanh = torch.nn.Tanh()
        self.layer3 = torch.nn.Linear(self.output_dim, 1)
        self.out_sigmoid = torch.nn.Sigmoid()

    def forward(self, x, classify=True):
        x = self.layer1(x)
        x = self.tanh(x)
        x = self.layer2(x)
        output = self.sigmoid(x) / np.sqrt(self.output_dim)
        output = F.normalize(output, dim=1)

        if classify:
            output = self.layer3(output)
            output = self.out_sigmoid(output)

        return output

class LinearClassifier(torch.nn.Module):

    def __init__(self, input_dim):
        super(LinearClassifier, self).__init__()
        self.input_dim = input_dim
        self.layer = torch.nn.Linear(self.input_dim, 1)
        self.sigmoid = torch.nn.Sigmoid()

    def forward(self, x):
        x = self.layer(x)
        output = self.sigmoid(x)

        return output


class NeuralNet:

    def __init__(self, input_dim, hidden_dim=20, output_dim=50, linear=False):
        if linear:
            self.model = LinearClassifier(input_dim)
        else:
            self.model = MLP_with_classification(input_dim, hidden_dim, output_dim)

    def fit(self, X, y,  n_epochs=30000):

        assert type(X) == np.ndarray
        assert type(y) == np.ndarray

        X, X_dev, y, y_dev = train_test_split(
            X, y, test_size=0.2, stratify=y, random_state=42
        )

        X = torch.tensor(X, dtype=torch.float)
        y = torch.tensor(y.reshape(-1,1), dtype=torch.float)
        X_dev = torch.tensor(X_dev, dtype=torch.float)
        y_dev = torch.tensor(y_dev.reshape(-1,1), dtype=torch.float)

        criterion = torch.nn.BCELoss()
        optimizer = torch.optim.RMSprop(self.model.parameters())
        es = EarlyStopping(patience=10)

        # Optimizing Neural Network...

        self.model.train()
        for epoch in range(n_epochs):
            optimizer.zero_grad()
            X_out = self.model(X)
            loss = criterion(X_out, y)

            X_dev_out = self.model(X_dev)
            loss_dev = criterion(X_dev_out, y_dev)
            if es.step(loss_dev):
                break

            loss.backward()
            optimizer.step()

        self.model.eval()

    def predict(self, X):

        assert type(X) == np.ndarray

        X = torch.tensor(X, dtype=torch.float)

        self.model.eval()
        preds = self.model(X)
        preds_np = preds.detach().numpy()

        return np.array(preds_np, dtype=np.float64)


class NeuralNetWithPretraining:

    def __init__(self, input_dim, hidden_dim=20, output_dim=50):
        self.model = MLP_pretrain(input_dim, hidden_dim, output_dim)

    def fit(self, X, y, n_epochs=30000, method='supervised'):

        assert type(X) == np.ndarray
        assert type(y) == np.ndarray

        X, X_dev, y, y_dev = train_test_split(
            X, y, test_size=0.2, stratify=y, random_state=42
        )

        X = torch.tensor(X, dtype=torch.float)
        y_tensor = torch.tensor(y.reshape(-1,1), dtype=torch.float)
        X_dev = torch.tensor(X_dev, dtype=torch.float)
        y_dev_tensor = torch.tensor(y_dev.reshape(-1,1), dtype=torch.float)

        criterion = None
        if method=='supervised':
            criterion = loss_functions.supervisedDotProductLoss_torch
        elif method=='unsupervised':
            criterion = loss_functions.dotProductLoss_torch
        elif method=='mmd':
            criterion = loss_functions.MMDLoss_torch

        supervised = True
        if method == 'unsupervised':
            supervised = False


        optimizer = torch.optim.Rprop(self.model.parameters())
        es_pre = EarlyStopping(patience=10)

        # Optimizing Neural Network...

        print("Pretraining...")

        self.model.train()
        for epoch in range(n_epochs):
            optimizer.zero_grad()
            X_out = self.model(X, classify=False)
            X_dev_out = self.model(X_dev, classify=False)
            if supervised:
                loss = criterion(X_out, y, normalize=False)
                loss_dev = criterion(X_dev_out, y_dev)
            else:
                loss = criterion(X_out, normalize=False)
                loss_dev = criterion(X_dev_out)

            if es_pre.step(loss_dev):
                break

            loss.backward()
            optimizer.step()

        criterion_class = torch.nn.BCELoss()
        optimizer_class = torch.optim.Rprop(self.model.parameters())
        es = EarlyStopping(patience=10)

        print("Fitting classifier...")

        self.model.train()
        for epoch in range(n_epochs):
            optimizer.zero_grad()
            X_out = self.model(X, classify=True)
            X_dev_out = self.model(X_dev, classify=True)
            loss = criterion_class(X_out, y_tensor)
            loss_dev = criterion_class(X_dev_out, y_dev_tensor)

            if es.step(loss_dev):
                break

            loss.backward()
            optimizer_class.step()

        self.model.eval()

    def predict(self, X):

        assert type(X) == np.ndarray

        X = torch.tensor(X, dtype=torch.float)

        self.model.eval()
        preds = self.model(X)
        preds_np = preds.detach().numpy()

        return np.array(preds_np, dtype=np.float64)
