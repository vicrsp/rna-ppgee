import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import os
import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd as autograd
import torch.optim as optim

from collections import Counter
from kerneloptimizer.neural_nets.mlp.early_stopping import EarlyStopping
from scipy.spatial import distance_matrix
from scipy.stats import spearmanr, pearsonr
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

PLOT = False
PLOT_FREQ = 1
CLASSIFY = True

def row_pairwise_distances(x, y=None, dist_mat=None):
    if y is None:
        y = x
    if dist_mat is None:
        dtype = x.data.type()
        dist_mat = torch.autograd.Variable(
            torch.Tensor(x.size()[0], y.size()[0]).type(dtype))

    for i, row in enumerate(x.split(1)):
        r_v = row.expand_as(y)
        sq_dist = torch.sum((r_v - y) ** 2, 1)
        dist_mat[i] = sq_dist.view(1, -1)
    return dist_mat


def dotProductLoss(X, normalize=False, gram_mat=None):

    if normalize:
        X = F.normalize(X, dim=1)

    #gram_mat = torch.mm(X, X.t())
    if gram_mat is None:
        dist_mat = row_pairwise_distances(X)
        gram_mat = torch.exp(-.5 * torch.pow(dist_mat, 2) / (.1 ** 2))
    means = torch.mean(gram_mat, dim=1)
    loss = means.var()

    final_loss = (-1 * loss)
    #print(final_loss)

    return final_loss


def contractiveDotProductLoss(X_out, X, normalize=False, lamb=1e-2):

    if normalize:
        X_out = F.normalize(X_out, dim=1)

    #X_out.backward(torch.ones(X_out.size()), retain_graph=True)
    #penalty = torch.sqrt(torch.sum(pow(X.grad,2)))
    W = model.layer.weight.data
    dh = X_out * (1 - X_out)
    penalty = lamb * torch.sum(dh**2 * torch.sum(W**2, axis=1), axis=1)

    #from IPython import embed
    #embed()

    #X.grad.requires_grad_(True)
    gram_mat = torch.mm(X_out, X_out.t())
    means = torch.mean(gram_mat, dim=1)
    loss = means.var()
    #from IPython import embed
    #embed()

    #X.grad.data.zero_()
    #print("Loss:",-1 * loss)
    #print("Jacob:",penalty.mean())
    final_loss = (-1 * loss) + penalty.mean()
    #final_loss = penalty.mean()
    #print(loss, penalty, final_loss)

    return final_loss * 100


def dotProductLossMeans(means, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    loss = means.var()

    return -1 * loss


def supervisedDotProductLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    N = gram_mat.shape[0]
    gram_mat = gram_mat * (1 - torch.eye(N))
    class_count = dict(Counter(np.array(y)))

    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    #from IPython import embed
    #embed()

    #sim_to_c0 = torch.mean(gram_mat[:,which_c0],dim=1)
    #sim_to_c1 = torch.mean(gram_mat[:,which_c1],dim=1)
    y = torch.tensor(y, dtype=torch.float32)
    sim_to_c0 = torch.sum(gram_mat[:, which_c0],
                          dim=1)/(class_count[0] - 1*(y == 0))
    sim_to_c1 = torch.sum(gram_mat[:, which_c1],
                          dim=1)/(class_count[1] - 1*(y == 1))

    sim_c0_c0 = torch.mean(sim_to_c0[which_c0])
    sim_c0_c1 = torch.mean(sim_to_c1[which_c0])
    sim_c1_c0 = torch.mean(sim_to_c0[which_c1])
    sim_c1_c1 = torch.mean(sim_to_c1[which_c1])

    loss = (sim_c0_c0 - sim_c1_c0) ** 2 + (sim_c1_c1 - sim_c0_c1) ** 2
    return -1 * loss


def MMDLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    N = gram_mat.shape[0]
    gram_mat = gram_mat * (1 - torch.eye(N))
    class_count = dict(Counter(np.array(y)))

    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    #from IPython import embed
    #embed()

    #sim_to_c0 = torch.mean(gram_mat[:,which_c0],dim=1)
    #sim_to_c1 = torch.mean(gram_mat[:,which_c1],dim=1)
    y = torch.tensor(y, dtype=torch.float32)
    sim_to_c0 = torch.sum(gram_mat[:, which_c0],
                          dim=1)/(class_count[0] - 1*(y == 0))
    sim_to_c1 = torch.sum(gram_mat[:, which_c1],
                          dim=1)/(class_count[1] - 1*(y == 1))

    sim_c0_c0 = torch.mean(sim_to_c0[which_c0])
    sim_c0_c1 = torch.mean(sim_to_c1[which_c0])
    sim_c1_c0 = torch.mean(sim_to_c0[which_c1])
    sim_c1_c1 = torch.mean(sim_to_c1[which_c1])

    loss = sim_c0_c0 + sim_c1_c1 - 2*sim_c0_c1
    return -1 * loss


def determinantDotProductLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    sim_to_c0 = torch.mean(gram_mat[:, which_c0], dim=1)
    sim_to_c1 = torch.mean(gram_mat[:, which_c1], dim=1)

    sim_c0_c0 = torch.mean(sim_to_c0[which_c0])
    sim_c0_c1 = torch.mean(sim_to_c1[which_c0])
    sim_c1_c0 = torch.mean(sim_to_c0[which_c1])
    sim_c1_c1 = torch.mean(sim_to_c1[which_c1])

    #loss = (sim_c0_c0 - sim_c1_c0) ** 2 + (sim_c1_c1 - sim_c0_c1) ** 2
    loss = (sim_c0_c0 * sim_c1_c1) - (sim_c0_c1 * sim_c1_c0)
    return -1 * loss


def supvarDotProductLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    sim_to_c0 = torch.mean(gram_mat[:, which_c0], dim=1)
    sim_to_c1 = torch.mean(gram_mat[:, which_c1], dim=1)

    loss = sim_to_c0.var() + sim_to_c1.var()
    return -1 * loss


def mixedDotProductLoss(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    sim_to_c0 = torch.mean(gram_mat[:, which_c0], dim=1)
    sim_to_c1 = torch.mean(gram_mat[:, which_c1], dim=1)

    sim_c0_c0 = torch.mean(sim_to_c0[which_c0])
    sim_c0_c1 = torch.mean(sim_to_c1[which_c0])
    sim_c1_c0 = torch.mean(sim_to_c0[which_c1])
    sim_c1_c1 = torch.mean(sim_to_c1[which_c1])

    means = torch.mean(gram_mat, dim=1)
    loss_nsup = means.std() ** 2
    loss_sup = (sim_c0_c0 - sim_c1_c0) ** 2 + (sim_c1_c1 - sim_c0_c1) ** 2

    loss = loss_sup + loss_nsup
    return -1 * loss


class SimpleMLP(torch.nn.Module):

    def __init__(self, input_dim, output_dim):
        super(SimpleMLP, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.layer = torch.nn.Linear(self.input_dim, self.output_dim)
        #torch.manual_seed(2)
        #self.layer.weight.data.uniform_(-10.0, 10.0)
        self.layer.weight.data.normal_()
        self.sigmoid = torch.nn.Sigmoid()
        self.softplus = torch.nn.Softplus()
        self.tanh = torch.nn.Tanh()

    def forward(self, x):
        x = self.layer(x)
        output = self.sigmoid(x)  # / np.sqrt(self.output_dim)
        #output = F.normalize(output, dim=1)

        return output


class MLP(torch.nn.Module):

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MLP, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.layer1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
        #self.layer1.weight.data.uniform_(-1.0, 1.0)
        torch.manual_seed(2)
        self.layer1.weight.data.uniform_(-1.0, 1.0)
        #nn.init.ones_(self.layer1.weight)
        #self.layer1.weight.data.fill_(1.0)
        #self.layer1.bias.data.fill_(1.0)
        self.tanh = torch.nn.Tanh()
        self.layer2 = torch.nn.Linear(self.hidden_dim, self.output_dim)
        #self.layer2.weight.data.uniform_(-1.0, 1.0)
        torch.manual_seed(2)
        self.layer2.weight.data.uniform_(-1.0, 1.0)
        #nn.init.ones_(self.layer2.weight)
        #self.layer2.weight.data.fill_(1.0)
        #self.layer2.bias.data.fill_(1.0)
        self.sigmoid = torch.nn.Sigmoid()
        self.relu = torch.nn.ReLU()
        self.tanh = torch.nn.Tanh()

    def forward(self, x, calc_gram=False):
        x = self.layer1(x)
        x = self.tanh(x)
        x = self.layer2(x)
        #output = self.relu(x)
        output = self.sigmoid(x)  # / np.sqrt(self.output_dim)
        output = F.normalize(output, dim=1)

        #if calc_gram:
        #    dist_mat = row_pairwise_distances(output)
        #    gram_mat = torch.exp(-.5 * torch.pow(dist_mat,2) / (.1 ** 2))
        #    return gram_mat

        return output


class DeepMLP(torch.nn.Module):

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(DeepMLP, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.layer1 = torch.nn.Linear(self.input_dim, self.hidden_dim)
        self.layer1.weight.data.normal_(0.0, 10.0)
        self.layer2 = torch.nn.Linear(self.hidden_dim, self.hidden_dim)
        self.layer2.weight.data.normal_(0.0, 10.0)
        self.layer3 = torch.nn.Linear(self.hidden_dim, self.hidden_dim)
        self.layer3.weight.data.normal_(0.0, 10.0)
        self.layer4 = torch.nn.Linear(self.hidden_dim, self.hidden_dim)
        self.layer4.weight.data.normal_(0.0, 10.0)
        self.layer5 = torch.nn.Linear(self.hidden_dim, self.hidden_dim)
        self.layer5.weight.data.normal_(0.0, 10.0)
        self.layer6 = torch.nn.Linear(self.hidden_dim, self.hidden_dim)
        self.layer6.weight.data.normal_(0.0, 10.0)
        self.layer7 = torch.nn.Linear(self.hidden_dim, self.output_dim)
        self.layer7.weight.data.normal_(0.0, 10.0)
        self.tanh = torch.nn.Tanh()
        self.sigmoid = torch.nn.Sigmoid()
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        x = self.layer1(x)
        x = self.sigmoid(x)
        x = self.layer2(x)
        x = self.sigmoid(x)
        x = self.layer3(x)
        x = self.sigmoid(x)
        x = self.layer4(x)
        x = self.sigmoid(x)
        x = self.layer5(x)
        x = self.sigmoid(x)
        x = self.layer6(x)
        x = self.sigmoid(x)
        x = self.layer7(x)
        output = self.sigmoid(x) / np.sqrt(self.output_dim)
        #output = F.normalize(output, dim=1)

        return output


def get_sim_space(X, y, normalize=False):

    if normalize:
        X = F.normalize(X, dim=1)

    gram_mat = torch.mm(X, X.t())
    N = gram_mat.shape[0]
    gram_mat = gram_mat * (1 - torch.eye(N))
    class_count = dict(Counter(np.array(y)))

    which_c0 = np.where(y == 0)[0]
    which_c1 = np.where(y == 1)[0]

    y = torch.tensor(y, dtype=torch.float32)
    sim_to_c0 = torch.sum(gram_mat[:, which_c0],
                          dim=1)/(class_count[0] - 1*(y == 0))
    sim_to_c1 = torch.sum(gram_mat[:, which_c1],
                          dim=1)/(class_count[1] - 1*(y == 1))

    return np.array([sim_to_c0.detach().numpy(), sim_to_c1.detach().numpy()])


X = pd.read_csv('data/spirals_data.csv')
#X = pd.read_csv('data/spirals_data_2.csv')
#X = pd.read_csv('data/singlespiral.csv')
#X = pd.read_csv('data/normals_data.csv')
#X = pd.read_csv('data/benchmarks/glass.csv')
N = X.shape[0]
np.random.seed(2)
idx = np.random.permutation(N)
lim_test = round(N/10)
idx_test = idx[:lim_test]
idx_train = idx[lim_test:]

X_test = X.iloc[idx_test]
X = X.iloc[idx_train]
original_df = X

distmat_train = distance_matrix(X.to_numpy(), X.to_numpy())
mean_dists = distmat_train.mean(axis=1)

target_var = 'Target'
if target_var not in X.columns:
    target_var = 'V3'
y = X.pop(target_var).to_numpy() - 1
y_test = X_test.pop(target_var).to_numpy() - 1
y_tensor = torch.tensor(y).view(-1, 1)

X = torch.tensor(X.to_numpy(), dtype=torch.float)
X_test = torch.tensor(X_test.to_numpy(), dtype=torch.float)

d = X.shape[1]

model = MLP(
    input_dim=d,
    hidden_dim=15,
    output_dim=20
)

#model = DeepMLP(
#    input_dim=d,
#    hidden_dim=10,
#    output_dim=7
#)

#model = SimpleMLP(
#    input_dim=d,
#    output_dim=10*d
#)

#criterion = dotProductLoss
#criterion = contractiveDotProductLoss
#criterion = determinantDotProductLoss
#criterion = dotProductLossMeans
#criterion = supervisedDotProductLoss
criterion = MMDLoss
#criterion = mixedDotProductLoss
#criterion = supvarDotProductLoss

#optimizer = torch.optim.SGD(model.parameters(), lr=.1)
optimizer = torch.optim.Rprop(model.parameters())
#optimizer = torch.optim.Adam(model.parameters())#, weight_decay=1e-5)
#optimizer = torch.optim.RMSprop(model.parameters())

model.eval()
X_out = model(X)
X_test_out = model(X_test)

x_before_np = X_out.detach().numpy()
x_test_before_np = X_test_out.detach().numpy()
es = EarlyStopping(patience=20)

if CLASSIFY:
    clf = SVC(kernel='linear')
    clf.fit(x_before_np, y)
    preds = clf.predict(x_before_np)
    print("Accuracy of a linear SVM in training set:", accuracy_score(y, preds))

    preds_test = clf.predict(x_test_before_np)
    print("Accuracy of a linear SVM in test set:",
          accuracy_score(y_test, preds_test))

#before_train = criterion(X_out, y)
#before_train = criterion(X_out)
#print('Loss before train: {}'.format(before_train))


def get_jacobian(net, x, noutputs):
    x = x.squeeze()
    n = x.size()[0]
    x = x.repeat(noutputs, 1)
    x.requires_grad_(True)
    y = net(x)
    y.backward(torch.eye(noutputs))
    return x.grad.data


model.train()
n_epochs = 1000
loss_vals = np.zeros(n_epochs)
r_vals = np.zeros(n_epochs)
epochs = np.arange(n_epochs)
norms = np.arange(n_epochs)
plot = False
for epoch in epochs:
    try:
        optimizer.zero_grad()

        X.requires_grad_(True)
        X.retain_grad()
        X_test.requires_grad_(True)
        X_test.retain_grad()

        X_out = model(X)
        X_test_out = model(X_test)
        gram_mat = torch.mm(X_out, X_out.t())
        means = torch.mean(gram_mat, dim=1)

        total_norm = 0
        for p in model.parameters():
            param_norm = p.data.norm(2)
            total_norm += param_norm.item() ** 2
        norms[epoch] = total_norm ** (1. / 2)

        gram_mat_dev = torch.mm(X_test_out, X_test_out.t())
        means_dev = torch.mean(gram_mat_dev, dim=1)

        #loss = criterion(means, normalize=False)
        #loss_dev = criterion(means_dev, normalize=False)
        #loss = criterion(X_out,normalize=False)
        #loss = criterion(X_out, X, normalize=True)
        #loss_dev = criterion(X_test_out, X_test, normalize=True)
        loss = criterion(X_out, y)  # , normalize=True)
        #loss_dev = criterion(X_test_out, y_test, normalize=True)
        loss_vals[epoch] = loss

        #if epoch % 100 == 0:
        print('Epoch {}: Loss: {}'.format(epoch, loss.item()))

        #if es.step(loss_dev):
        #    break

        loss.backward()
        optimizer.step()
        X.requires_grad_(False)
        X_test.requires_grad_(False)

        means_np = means.detach().numpy()
        r_vals[epoch] = spearmanr(means_np, mean_dists)[0]
        #r_vals[epoch] = pearsonr(means_np, mean_dists)[0]
        if (epoch % PLOT_FREQ == 0):
            #X_out_np = X_out.detach().numpy().transpose()
            sim_space = get_sim_space(X_out, y)
            #from IPython import embed
            #embed()
            fig, ax = plt.subplots()
            ax.scatter(sim_space[0][np.where(y == 0)],
                       sim_space[1][np.where(y == 0)],
                       label='0',
                       c='blue')
            ax.scatter(sim_space[0][np.where(y == 1)],
                       sim_space[1][np.where(y == 1)],
                       label='1',
                       c='red')
            #if loss.item() == -4.0:
            #    from IPython import embed
            #    embed()
            plt.xlim(0, 1)
            plt.ylim(0, 1)
            plt.xlabel('Sim to class 0')
            plt.ylabel('Sim to class 1')
            plt.title('Epoch: {}'.format(epoch))
            ax.legend()
            plt.savefig(
                'plots/mlp/mmd_simspace/SimSpace_Epoch{}.png'.format(epoch))
            plt.close(fig)
            plt.clf()
    except KeyboardInterrupt:
        print("Keyboard interruption! Saving results as they are...")
        loss_vals = loss_vals[:epoch]
        r_vals = r_vals[:epoch]
        epochs = epochs[:epoch]
        break


if PLOT:
    plt.clf()

X_out_np = X_out.detach().numpy()
mean_dists_out = distance_matrix(X_out_np, X_out_np).mean(axis=1)

plt.scatter(mean_dists, means_np)
plt.savefig('plots/mlp/kernelvsdist.png')
plt.clf()

original_df['MeanDotProd'] = means_np
original_df['MeanOutDist'] = mean_dists_out
original_df.to_csv('data/spirals_with_mean_dot.csv', index=False)


plt.plot(epochs, loss_vals)
plt.savefig('plots/mlp/loss.png')
plt.clf()

#plt.plot(epochs, norms)
#plt.savefig('plots/mlp/param_norms.png')
#plt.clf()

plt.plot(epochs, r_vals)
plt.savefig('plots/mlp/spearman.png')

model.eval()
x_final = model(X)
x_test_final = model(X_test)

x_final_np = x_final.detach().numpy()
x_test_final_np = x_test_final.detach().numpy()

if CLASSIFY:
    clf = SVC(kernel='linear')
    clf.fit(x_final_np, y)
    preds = clf.predict(x_final_np)
    print("Accuracy of a linear SVM in training set:", accuracy_score(y, preds))

    preds_test = clf.predict(x_test_final_np)
    print("Accuracy of a linear SVM in test set:",
          accuracy_score(y_test, preds_test))

x_final_with_class = np.append(
    x_final_np,
    y.reshape(-1, 1),
    axis=1
)

np.savetxt("data/final_projections.csv", x_final_with_class, delimiter=",")
x_final_plot = x_final_np.transpose()

plt.clf()
plt.scatter(x_final_plot[0], x_final_plot[1], c=y)
plt.xlim(0, 1)
plt.ylim(0, 1)
plt.savefig('plots/mlp/final_conf.png')
